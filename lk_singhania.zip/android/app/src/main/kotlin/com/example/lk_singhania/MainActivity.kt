package com.example.lk_singhania

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
