import 'package:lk_singhania/page/principal.dart';
import 'package:flutter/material.dart';

import '../page/about.dart';
import '../page/contact-us.dart';
import '../page/home.dart';
import '../page/rules.dart';

class Drawers extends StatelessWidget {
  const Drawers({super.key});

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Drawer(
        child: ListView(
          padding: EdgeInsets.zero,
          children: [
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Image.asset("assets/logo.png",
              height: 125,),
            ),
           const Text('LK Singhania School',
           style: TextStyle(fontSize: 20),
           textAlign: TextAlign.center,
           ),
           const SizedBox(height: 20,),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Home(),
                  ),
                );
              },
              child: const ListTile(
                leading: Icon(
                  Icons.home,
                  size: 26,
                ),
                title: Text(
                  "Home",
                  textScaler: TextScaler.linear(1.2),
                  textAlign: TextAlign.justify,
                ),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Principal(),
                  ),
                );
              },
              child: const ListTile(
                leading: Icon(
                  Icons.person,
                  size: 26,
                ),
                title: Text(
                  "Principal's Desk",
                  textScaler: TextScaler.linear(1.2),
                  textAlign: TextAlign.justify,
                ),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Rules(),
                  ),
                );
              },
              child: const ListTile(
                leading: Icon(
                  Icons.rule,
                  size: 26,
                ),
                title: Text(
                  "Rules",
                  textScaler: TextScaler.linear(1.2),
                  textAlign: TextAlign.justify,
                ),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const Contact(),
                  ),
                );
              },
              child: const ListTile(
                leading: Icon(
                  Icons.email,
                  size: 26,
                ),
                title: Text(
                  "Contact Us",
                  textScaler: TextScaler.linear(1.2),
                  textAlign: TextAlign.justify,
                ),
              ),
            ),
            InkWell(
              onTap: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => const About(),
                  ),
                );
              },
              child: const ListTile(
                leading: Icon(
                  Icons.edit,
                  size: 26,
                ),
                title: Text(
                  "About Us",
                  textScaler: TextScaler.linear(1.2),
                  textAlign: TextAlign.justify,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
