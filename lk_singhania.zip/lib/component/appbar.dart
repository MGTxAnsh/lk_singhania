import 'package:flutter/material.dart';

class CustomAppbar extends StatelessWidget implements PreferredSizeWidget {
  const CustomAppbar({super.key});

  @override
  Widget build(BuildContext context) {
    return AppBar(
      title: Row(
        children: [ // Add some space between text and image
          Image.asset(
            "assets/logo.png",
            height: 40,
          ),
          const SizedBox(width: 20,),
          const Text('L K SINGHANIA EDUCATION ',
          style: TextStyle(fontSize: 15),),
          
          
        ],
      ),
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(55);
}