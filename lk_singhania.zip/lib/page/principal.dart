import 'package:lk_singhania/component/appbar.dart';
import 'package:lk_singhania/component/drawer.dart';
import 'package:lk_singhania/util/principal/desk.dart';
import 'package:flutter/material.dart';

class Principal extends StatefulWidget {
  const Principal({super.key});

  @override
  State<Principal> createState() => _PrincipalState();
}

class _PrincipalState extends State<Principal> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppbar(),
      drawer: const Drawers(),
      body: ListView(
        children: const [Desk()],
      ),
    );
  }
}
