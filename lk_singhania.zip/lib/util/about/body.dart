import 'package:flutter/material.dart';

class Body extends StatelessWidget {
  const Body({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'About the School',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            Image.asset("assets/aboutpage.jpg"),
            const SizedBox(height: 10),
            const Text(
              'The LK Singhania Education Centre at Gotan came into existence as a full-fledged, premier residential school in July 1987 as a realization of the values and dreams of the great visionary, Late Lala Kamlapat Singhania. The school is Senior Secondary, co-educational English medium affiliated to the Central Board of Secondary Education, New Delhi. Accommodating 1650 students including 950 boarders from all parts of the country and internationally as well, the LK Singhania Education Centre is a unique mix of the traditional and modern. This centre is a multicultural, co-educational boarding school where traditions, religions and beliefs from all walks of life are respected and celebrated. The aim is to nurture each child individually to help them become global citizens.',
              style: TextStyle(
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'A dedicated and hardworking team of teachers soon put the school in formidable position and the school became quite popular in the town. By the start of new millennium Birla Shishu Vihar has earned a reputation of being the premier English medium school of the area.',
              style: TextStyle(
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'The parents from neighbouring cities/towns have also started flocking in to let their child alma mater of this prestigious temple of learning. Considering the popularity of the school, the management recommended for the up-gradation of the school which the Trustees immediately accepted. In 2001 class VI was started in the school and subsequently the school was affiliated to Secondary level with the Central Board of Secondary Examination (CBSE) in 2005. After that there was no looking back and today the school is a Senior Secondary Day school with ever blooming strength.',
              style: TextStyle(
                fontSize: 14,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'GENERAL FEATURES',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              ' Although the school was initiated in 1984 with the aim to provide education to the children of JK White Cement employees only, with the great social commitment of the JK organization, it meant that the school should be expanded to provide quality education to the children of one and all with the non-profit motive. Since then, the school has grown from strength to strength in every sphere of education as well as in sports and extracurricular activities to provide an integrated learning environment for all its students.  The prominent transformational phase in its history came in 1987 when the centre started providing boarding facilities to students from all over India and abroad. The school is fully equipped with ultramodern educational facilities to ensure that all the needs of students for a truly holistic development are met with. All types of co-curricular activities, sports and games are highly encouraged for a perfect all-round development of students. ',
              style: TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 20),
            const Text(
              'LOCATION',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'Gotan is a Small Hamlet in the District of Nagaur, Rajasthan. The school is located in a beautiful campus. Gotan is an industrial township and easily Accessible by road and broad gauge rail from Delhi, Mumbai, Kolkata, Guwahati, Jodhpur, Jaipur, Ajmer, Kota, Agra Lucknow, Chandigarh, Kalka etc. Gotan railway station is about 2 kms. From the school. Bus services from Nagaur and Ajmer are Very frequent and easily available via Merta City.The nearest aerodrome is just 110 Kms. away from jodhpur  ',
              style: TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 10),
            const Text(
              'INFRASTRUCTURE',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 10),
            const Text(
              'The school has a beautiful dome like structure. Junior school building and senior school building are separate. It has a large football ground, cricket ground, basketball courts, volleyball courts, table tennis rooms, lawn tennis court, indoor badminton courts,skating rink, large swimming pool with nine lanes',
              style: TextStyle(fontSize: 14),
            ),
          ],
        ));
  }
}
