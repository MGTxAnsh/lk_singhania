import 'package:flutter/material.dart';

class ContactBody extends StatelessWidget {
  const ContactBody({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Contact Us",
            style: TextStyle(fontSize: 26),
          ),
          const SizedBox(
            height: 20,
          ),
          const Text(
            'LK Singhania Education Centre',
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'Lala Kamlapat Singhania Education Centre, Gotan, district Nagaur, Rajasthan – 342 902 India',
            style: TextStyle(color: Color.fromARGB(255, 37, 37, 37)),
          ),
          const SizedBox(height: 8),
          const Text(
            'Telephone: 01596 - 242208',
            style: TextStyle(color: Color.fromARGB(255, 37, 37, 37)),
          ),
          const SizedBox(height: 8),
          const Text(
            'Email: info@lksec.org',
            style: TextStyle(color: Color.fromARGB(255, 37, 37, 37)),
          ),
          const SizedBox(height: 24),
          const Text(
            'Send Us Your Information',
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 16),
          const Text(
            'Your Name',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const TextField(
            decoration: InputDecoration(
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Your Email',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const TextField(
            decoration: InputDecoration(
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 16),
          const Text(
            'Your Hobbies',
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          const TextField(
            decoration: InputDecoration(
              border: OutlineInputBorder(),
            ),
            maxLines: 5,
          ),
          const SizedBox(height: 16),
          InkWell(
            onTap: () {},
            child: Container(
              width: MediaQuery.of(context).size.width,
              height: 60,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(8),
                color: const Color.fromRGBO(0, 57, 119, 1.0),
              ),
              child: const Center(
                child: Text(
                  "Send a Message",
                  style: TextStyle(color: Colors.white, fontSize: 16),
                ),
              ),
            ),
          )
        ],
      ),
    );
  }
}
