import 'package:flutter/material.dart';

class News extends StatefulWidget {
  const News({super.key});

  @override
  State<News> createState() => _NewsState();
}

List<String> news = [
  "Rank 1st with rating AAAA+ among Best Day Schools of Rajasthan State by Career-360.",
  "LK Singhania Education Centre,Gotan observed the inauguration of Van Mahotsav Week from July 4th to 11th,2024.",
  "Career fair & Career counselling session - 09:00 am - 01:00 pm on 30-04-2024.",
  "Investiture Ceremony: LK Singhanai Education Centre hosted ‘Investiture Ceremony’ for its newly appointed student council for the session 2024-2025 on 10th April ,2024.",
  "BSV Added Another feather To Its Cap By Qualifying For GLI Certification.",
  "Teachers workshop on \"story telling as Pedagory\" by CoE, Ajmer - 08:30 am - 04:30 pm on 30-04-2024",
  "Inter-House kabaddi Finals Senior- Boys & Girls on 10-05-2024.",
  "A Pious Beginning of the New Session: The new academic session at BSV commenced on April 1st ,2024 with the worship of Goddess Saraswati, symbolizing the pursuit of knowledge and wisdom. The chanting of ‘Mantras ‘by students and teachers reinforced a sense of ecstasy in the vicinity.",
  "School has been Accredited by - NABET",
];

class _NewsState extends State<News> {
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: MediaQuery.of(context).size.width,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(
            height: 10,
          ),
          const Padding(
            padding: EdgeInsets.symmetric(horizontal: 15.0),
            child: Text(
              "News",
              style: TextStyle(fontSize: 20),
              textAlign: TextAlign.start,
            ),
          ),
          ListView.builder(
            physics: const NeverScrollableScrollPhysics(),
            addAutomaticKeepAlives: false,
            shrinkWrap: true,
            itemCount: news.length,
            itemBuilder: (context, index) {
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  ListTile(
                    title: Text(
                      news[index],
                      textAlign: TextAlign.justify,
                    ),
                    tileColor: Colors.grey[200],
                  ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}
