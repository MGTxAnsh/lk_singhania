// ignore_for_file: must_be_immutable

import 'package:carousel_slider/carousel_slider.dart';
import 'package:flutter/material.dart';

class ImageSlide extends StatelessWidget {
  ImageSlide({super.key});

  List<String> image = [
    "assets/image1.jpg",
    "assets/image 2.jpg",
    "assets/image3.jpg",
    "assets/image4.jpg",
    "assets/image5.jpg",
    "assets/image6.jpg",
    "assets/image7.jpg",
    "assets/image8.jpeg",
    "assets/image9.jpeg",
  ];

  @override
  Widget build(BuildContext context) {
    return CarouselSlider(
      options: CarouselOptions(autoPlay: true),
      items: image
          .map(
            (item) => Container(
              child: Center(
                child: Image.asset(
                  item.toString(),
                  fit: BoxFit.cover,
                  width: 1000,
                  height: 400,
                ),
              ),
            ),
          )
          .toList(),
    );
  }
}
