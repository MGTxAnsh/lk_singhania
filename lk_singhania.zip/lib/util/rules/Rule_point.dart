import 'package:flutter/material.dart';

class RulePoint extends StatelessWidget {
  const RulePoint({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'SCHOOL RULES',
            style: TextStyle(
              color: Color.fromARGB(255, 23, 42, 110),
              fontSize: 26,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          Image.asset("assets/rules_page.jpg"),
          const SizedBox(height: 10),
          const Text(
            '• It is compulsory for all the students to come to the school in prescribed school uniform. The turnout should be of high standard. The uniform should be clean and well ironed. Personal hygiene should also be maintained. The boys are not allowed to keep long hair. These should be well trimmed.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
          const SizedBox(height: 10),
          const Text(
            '• Students must be punctual for the school. Late comers will not be allowed entry.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
          const SizedBox(height: 10),
          const Text(
            '• The students should be regular in their classes. A student whose attendance is less than 75% in an academic year will not be permitted to appear for the final examination.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
          const SizedBox(height: 10),
          const Text(
            '• Leave will be granted if there is a genuine cause for which a written request is required to be sent to the Principal. Absentees will be fined.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
          const SizedBox(height: 10),
          const Text(
            '• Damage to the school property is to be made good by the parents of the students involved.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
          const SizedBox(height: 10),
          const Text(
            '• Defacing the school walls, furniture and other property is forbidden, violation of school rules is subject to punishment.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
          const SizedBox(height: 10),
          const Text(
            '• The students should show respect and reverence towards the school rules and the teachers. The student should be gentle, polite and co-operative towards the fellow students.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
          const SizedBox(height: 10),
          const Text(
            '• It is prohibited to bring any book other than the text books to the school unless specified by the teacher.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
          const SizedBox(height: 10),
          const Text(
            '• Students are not allowed to wear expensive jewellery or bring any other expensive item. Mobile phones can not be brought to the school. The students are also advised not to use mehndi or tattoos.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
          const SizedBox(height: 10),
          const Text(
            '• Books are to be brought in the school bags (Rucksacks cannot be used as the school bags) soft binding of the books and exercise books is advisable to reduce the load of the bag.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
          const SizedBox(height: 10),
          const Text(
            '• Cycles are to be kept at the cycle stand. Students below class III are not allowed to bring their cycles in the school.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
          const SizedBox(height: 10),
          const Text(
            '• The students should look after their belongings. The school is not liable for the loss of any item of the student.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
          const SizedBox(height: 10),
          const Text(
            '• In the event of the indiscipline and a behaviour which could be termed as bad influence or immoral, the student is liable to be expelled from the school.',
            style: TextStyle(fontSize: 18),
            textAlign: TextAlign.justify,
          ),
        ],
      ),
    );
  }
}
