import 'package:flutter/material.dart';

class Desk extends StatelessWidget {
  const Desk({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(15.0),
      child: Column(
        children: [
          const Text(
            'Principal\'s Desk',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 10),
          Image.asset(
            "assets/principal.jpg",
          ),
          const SizedBox(
            height: 10,
          ),
          const Text(
            'Mr.R.C Joshi',
            style: TextStyle(fontSize: 24),
          ),
          const Text(
            '(Principal)',
            style: TextStyle(fontSize: 18),
          ),
          const SizedBox(height: 20),
          const Text(
            'An individual differs from others use to life which include its value and ideas, to develop the right reason in our children is to create a generation of truly educated, refined and noble citizens inspired and accept to serve the world in various capacities, there by fulfilling their life. We know the future of our children is not one of ease and comfort, but insistent striving and stiff competition, our emphasis is on imparting education which will enable character building and man-making. As Swami Vivekananda had visualized – Education is not the filling of the pale, but lighting on the burning desire to let it a spread of fire of enlightenment to end every bit of ignorance, following this reason the constant endeavor of Birla Shishu Vihar, Pilani has been to motivate students to do the best with their desire and leave their golden footprints for others to follow. ',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 10),
          const Text(
            'The school is not only centre of learning but also encompasses a strong bond between faculty members, parents and the students where children are never robbed of their independence rather encouraged to gather the complete advantage of being under rules and regulations, because the school believes that whenever the adults seek control on a child, the child is lost forever. We are grooming our students to be confident, happy and secured youth of tomorrow. They act as effective stepping stone to move from the familiar, safe cocoon of the home to the uncertain, challenging world outside.',
            style: TextStyle(fontSize: 16),
          ),
          const SizedBox(height: 10),
        ],
      ),
    );
  }
}
